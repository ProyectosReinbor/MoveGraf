#include "Arista.h"
#include "Vertice.h"

Vertice* Arista::getVecino() {
    return vecino;
}

int Arista::getPeso() {
   return peso;
}
